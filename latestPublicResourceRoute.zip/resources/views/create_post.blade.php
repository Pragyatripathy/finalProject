
@extends('template')

@section('title', 'Create Post')

@section('content')

    @if (session('message'))
        <div class="alert alert-success">
            {{ session('message') }}
        </div>
    @endif

    @if (session('error'))
        <div class="alert alert-error">
            {{ session('error') }}
        </div>
    @endif

    <form method="POST">
        @csrf
        <input type="" name="user_id" value=3 /><br>
        <label for="title">Title of your Post (optional)</label><br>
        <input name="title" value="hey people" /><br>
        <label for="text">Content of your Post</label><br>
        <textarea name="text" placeholder="your text here">Look I have found this awesome tool: kjanvkjavkjanvk</textarea><br>
        <label for="nameoftool">Name of the Tool (mandatory)</label><br>
        <input name="nameoftool" value="Google Pixel 6" /><br>
        <label for="linktotool">Link to the Tool (mandatory)</label><br>
        <input name="linktotool" value="https://www.amazon.com/Google-Pixel-6a-Smartphone-Megapixel/dp/B0B3PSRHHN/ref=sr_1_3?keywords=smartphone&qid=1670675213&sprefix=smartphone%2Caps%2C268&sr=8-3" /><br>
        <input type="submit" value="submit post" />
    </form>

    
@endsection