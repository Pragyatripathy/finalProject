@extends('template')

@section('content')

@if (session('message'))
<div class="alert alert-success">
    {{ session('message') }}
</div>
@endif

@if (session('error'))
<div class="alert alert-error">
    {{ session('error') }}
</div>
@endif

<div class="responsive-content">
    <div class="register-login">
        <div id="form-main">
            <div id="form-div">
                <form class="form" method="POST" id="form1">
                    @csrf
                    <p class="name">
                        <input name="firstname" type="text" class="feedback-input" placeholder="First Name" id="name"
                            value="HashedTest" />
                    </p>

                    <p class="email">
                        <input name="lastname" type="text" class="feedback-input" id="email" placeholder="Last Name"
                            value="HashedTest" />
                    </p>

                    <p class="email">
                        <input name="email" type="text" class="feedback-input" id="email" placeholder="Email"
                            value="hashed@email.com" />
                    </p>

                    <p class="email">
                        <input name="password" type="text" class="feedback-input" id="email" placeholder="Password"
                            value="1234567890" />
                    </p>

                    <p class="email">
                        <input name="confirmPassword" type="text" class="feedback-input" id="email"
                            placeholder="Confirm Password" value="1234567890" />
                    </p>
                    <div class="submit">
                        <input type="submit" value="Register" id="button-blue" />
                        <div class="ease"></div>
                    </div>
                </form>
            </div>
            <div class="register-image">
                <img src="assets/images/12.jpg" alt="image" width="500px">
            </div>
        </div>
    </div>



    @endsection