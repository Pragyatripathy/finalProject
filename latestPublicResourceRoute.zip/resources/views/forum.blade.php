
@extends('template')

@section('title', 'Posts list')

@section('content')

    @if (session('message'))
        <div class="alert alert-success">
            {{ session('message') }}
        </div>
    @endif

    @if (session('error'))
        <div class="alert alert-error">
            {{ session('error') }}
        </div>
    @endif

    
    @foreach ($posts as $post)
    @foreach ($users as $user)
    @if ($user->id == $post->user_id)
    <p><img src=https://robohash.org/{{ $user->avatar }}.jpg?bgset=bg2 /></p>
    <p>User {{ $user->username }} says:</p>
    @endif
    @endforeach
    <p>{{ $post->title }}</p>
    <p>{{ $post->text }}</p>
    <p>{{ $post->nameoftool }}</p>
    <p><img src=https://robohash.org/{{ $post->nameoftool }}.jpg?bgset=bg2 /></p>
        <p><a href={{ url($post->linktotool) }}>See tool on Amazon</a></p>
        <hr>
        

        
    @endforeach

@endsection