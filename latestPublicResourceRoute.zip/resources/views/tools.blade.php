@extends('template')

@section('title', 'tools list')

@section('content')

@if (session('message'))
<div class="alert alert-success">
    {{ session('message') }}
</div>
@endif

@if (session('error'))
<div class="alert alert-error">
    {{ session('error') }}
</div>
@endif

<form method="POST">
    @csrf
    <input type="submit" name="all" value="Show All">
    <input type="submit" name="smartphones" value="Show Smartphones Only">
    <input type="submit" name="laptops" value="Show laptops Only">
    <input type="submit" name="coffee_machines" value="Show coffee machines Only">
</form>

<h1><a href="store">Vist the Store</a></h1>

@foreach ($tools as $tool)
<a href="/tool-details/{{$tool->id}}">Click here to see details of {{$tool->name}}</a><br>
<a href="/buyTool/{{$tool->id}}">Click here to buy {{$tool->name}}</a><br>

<p>Picture : <img src=https://robohash.org/{{ $tool->picture }}.jpg?bgset=bg2 /></p>
<p>Name : {{ $tool->name }} | Watt : {{ $tool->watt }} | Rating : {{ $tool->rating }} | category : {{ $tool->category }}</p>
<hr>
@endforeach

@endsection