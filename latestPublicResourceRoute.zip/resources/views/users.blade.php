@extends('template')

@section('title', 'users list')

@section('content')

@if (session('message'))
<div class="alert alert-success">
    {{ session('message') }}
</div>
@endif

@if (session('error'))
<div class="alert alert-error">
    {{ session('error') }}
</div>
@endif



@foreach ($users as $user)
<p>Picture : <img src=https://robohash.org/{{ $user->avatar }}.jpg?bgset=bg2 /></p>
<p>id : {{ $user->id }}</p>
<p>First Name : {{ $user->firstname }}</p>
<p>Last Name : {{ $user->lastname }}</p>
<p>Daily Hours Energy Use : {{ $user->daily_hours_electricity_use }}</p>
<p>email : {{ $user->email }}</p>
<p>password : {{ $user->password }}</p>
<p>personal item : {{ $user->personal_item }}</p>
<hr>
@endforeach

@endsection