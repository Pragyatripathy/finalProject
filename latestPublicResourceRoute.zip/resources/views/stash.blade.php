<!DOCTYPE html>
<html>
<h1>This is an example view for the Final Project</h1>
<h1>LOGIN - enter either username or email (or both) and the password</h1>
<form>
    <input type="text" name="username" placeholder="your username" /><br>
    <input type="text" name="email" placeholder="your email" /><br>
    <input type="password" name="password" placeholder="your password" /><br>
    <input type="submit" name="loginBtn" value="Login" /><br>

</form>
<h1>REGISTER - all fields are mandatory</h1>
<form>
    <input type="text" name="username" placeholder="your username" /><br>
    <input type="password" name="password" placeholder="your password" /><br>
    <input type="text" name="email" placeholder="your email" /><br>
    <input type="submit" name="registerBtn" value="Register" /><br>
</form>

</html>
