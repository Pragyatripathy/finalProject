@extends('template')

@section('title', 'tools list')

@section('content')

@if (session('message'))
<div class="alert alert-success">
    {{ session('message') }}
</div>
@endif

@if (session('error'))
<div class="alert alert-error">
    {{ session('error') }}
</div>
@endif



@foreach ($tools as $tool)

<p><img src=https://robohash.org/{{ $tool->picture }}.jpg?bgset=bg2 /></p>
<a href="/buyTool/{{$tool->id}}">Click here to buy {{$tool->name}}</a>
<p>Name : {{ $tool->name }}</p>
<p>Watt : {{ $tool->watt }}</p>
<p>Rating : {{ $tool->rating }}</p>
<p>Amount Of Ratings : {{ $tool->amountOfRatings }}</p>
<p>Price : {{ $tool->price }}$</p>
<p>Seller : {{ $tool->seller }}</p>
<p>Serial Number : {{ $tool->serialnumber }}</p>
<hr>
@endforeach

@endsection