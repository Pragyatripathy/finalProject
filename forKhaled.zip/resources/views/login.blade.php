@extends('template')

@section('content')

<div class="responsive-content">
  <div class="register-login">
      <div id="form-main">
          <div id="form-div">
              <form method="POST" class="form" id="form1">
                @csrf
                  <p class="name">
                      <input name="email" type="text"
                          class="feedback-input"
                          placeholder="test@email.com" value="test@email.com" id="name" />
                  </p>

                  <p class="email">
                      <input name="password" type="text"
                          class="feedback-input" id="email"
                          placeholder="1234567890" value="1234567890" />
                  </p>   
                  <div class="submit">
                      <input type="submit" value="Login" id="button-blue" />
                      <div class="ease"></div>
                  </div>
              </form>
          </div>
          <div class="register-image">
          <img src="assets/images/12.jpg" alt="image" width="500px">
          </div>
      </div>
  </div>
  


@endsection