<?php

use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ToolController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PersonalToolController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [ToolController::class, 'index']);
Route::get('/home', [ToolController::class, 'index']);
Route::get('/error', [ToolController::class, 'error']);

Route::get('/addPersonalTool', [UserController::class, 'addPersonalTool']);
Route::post('/addPersonalTool', [UserController::class, 'insertPersonalTool']);

Route::get('/users', [UserController::class, 'index']);
Route::get('/personalTools', [PersonalToolController::class, 'index']);

Route::get('/register', [UserController::class, 'create']);
Route::post('/register', [UserController::class, 'store']);

Route::get('/login', [UserController::class, 'showLogin']);
Route::post('/login', [UserController::class, 'login']);

Route::get('/logout', [UserController::class, 'logOut']);

Route::get('/store', [ToolController::class, 'showStore']);
Route::get('/tools', [ToolController::class, 'index']);
Route::get('/buyTool/{id}', [ToolController::class, 'buyTool']);
Route::get('/tool-details/{id}', [ToolController::class, 'toolDetails']);
Route::post('/tool-details/{id}', [ToolController::class, 'insertRating']);
Route::get('/createTool', [ToolController::class, 'create']);
Route::post('/createTool', [ToolController::class, 'store']);

Route::get('/forum', [PostController::class, 'index']);
Route::get('/createPost', [PostController::class, 'create']);
Route::post('/createPost', [PostController::class, 'store']);

Route::get('/welcome', function () {
    return view('welcome');
});

/*/

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
});

require __DIR__.'/auth.php';

/*/