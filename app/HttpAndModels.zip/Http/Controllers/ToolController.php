<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\CreateToolRequest;
use App\Http\Requests\InsertRatingRequest;
use App\Models\Tool;

class ToolController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tools = Tool::all()->sortBy('watt');
        return view('tools', ['tools' => $tools]);
    }

    public function toolDetails($id)
    {
        $tool = Tool::where('id', $id)->first();
        return view('tool-details', ['tool' => $tool]);
    }
    public function buyTool($id)
    {
        $tool = Tool::where('id', $id)->first();
        return view('buy-tool', ['tool' => $tool]);
    }

    public function showStore()
    {
        $tools = Tool::all()->sortBy('watt');
        return view('store', ['tools' => $tools]);
    }

    public function error()
    {
        return view('error');
    }

    public function insertRating($id, InsertRatingRequest $request)
    {
        $oldRating = Tool::find($id)->get('rating');
        $oldAmountOfRatings = Tool::find($id)->get('amountOfRatings');
        $newAmountOfRatings = Tool::find($id)->update(['amountOfRatings' => $oldAmountOfRatings + 1]);
        $newRating = Tool::find($id)->update(['rating' => $oldRating + 1]);

        if ($newRating)
            return redirect('/tool-details')->with('message', 'Successfully rated !');
        else
            return redirect('/error')->with('message', 'Problem with rating !');

        /*/
        $currentRating = Tool::where('id', $id)->get('rating')->first();
        $amountOfRatings = Tool::where('id', $id)->get('amountOfRatings')->first();
        $newRating = ($currentRating * $amountOfRatings + $request->rating) / ($amountOfRatings + 1);
        $updateAmount = Tool::where('id', $id)->update(array('amountOfRatings' => $amountOfRatings++));
        if ($updateAmount && $updateRating)
        return redirect('/rate-tools')->with('message', 'Successfully rated !');
        else
        return redirect('/rate-tools')->with('message', 'Problem with rating !');
        /*/
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('create_tool');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreateToolRequest $request)
    {
        $request->validated();
        $tool = new Tool;

        $tool->name = $request->name;
        $tool->watt = $request->watt;
        $tool->picture = $request->picture;
        $tool->price = $request->price;
        $tool->seller_id = $request->seller;
        $tool->rating = $request->rating;
        $tool->serialnumber = $request->serialnumber;

        $result = $tool->save();
        if ($result)
            return redirect('/tools')->with('message', 'Successfully insert in the DB !');
        else
            echo "problem inserting";
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}